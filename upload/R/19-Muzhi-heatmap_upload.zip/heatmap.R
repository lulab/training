#This script draws a heatmap according to the given data.
install.packages("gplots")
library("gplots")
heatmap_data <- read.table("E:/lab/plotheatmap/R.heatmap.txt")
heatmap_matrix <- as.matrix(heatmap_data[ , 2:47])
heatmap.2(heatmap_matrix, col=colorRampPalette(c("white", "blue")), scale="column", keysize=1.5, trace="none", cexRow=0.47, cexCol=0.8)